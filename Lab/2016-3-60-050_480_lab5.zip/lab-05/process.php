<?php

    
    

    if($valid){

        include 'db_conn.php';

        $name = mysqli_real_escape_string($conn, $_POST['name']);
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $password = mysqli_real_escape_string($conn, $_POST['password']);
        $ip_address = mysqli_real_escape_string($conn, $_POST['ip_address']);
        $website = mysqli_real_escape_string($conn, $_POST['website']);
        $birthday = mysqli_real_escape_string($conn, $_POST['birthday']);
        $gender = mysqli_real_escape_string($conn, $_POST['gender']);
        $mobile = mysqli_real_escape_string($conn, $_POST['mobile']);
        $comment = mysqli_real_escape_string($conn, $_POST['comment']);


        $sql = "INSERT INTO `form1`(`name`, `email`, `password`, `id-address`, `website`, `birthday`, `gender`, `mobile-num`, `comment`) 
        VALUES ('$name', '$email', '$password', '$ip_address', '$website', '$birthday', '$gender', '$mobile', '$comment')";
        
        $result = mysqli_query($conn, $sql);

        if($result){
            header("Location: success.php");
            exit();
        }
    }




?>